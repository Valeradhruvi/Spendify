import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:spendify/transaction/add_transaction.dart';
import 'package:spendify/transaction/transaction_model.dart';
// import 'package:spendify/helpers/user_helper.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Transactions> transactions = [];
  double totalIncome = 0;
  double totalExpense = 0;

  @override
  void initState() {
    super.initState();
    fetchTransactionsFromFirebase();
    calculateTotals();
  }

  Future<void> fetchTransactionsFromFirebase() async {
    final uid =  '101';

    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('transactions')
        .orderBy('date', descending: true)
        .get();

    final txList = snapshot.docs.map((doc) {
      final data = doc.data();
      return Transactions(
        title: data['title'] ?? '',
        amount: (data['amount'] ?? '0').toString(),
        category: data['category'] ?? '',
        note: data['note'] ?? '',
        date: (data['date'] as Timestamp).toDate(),
        paymentMethod: data['paymentMethod'] ?? '',
        type: data['type'] ?? 'Expense',
      );
    }).toList();

    setState(() {
      transactions = txList;
    });
  }

  Future<void> calculateTotals() async {
    final uid =  '101';

    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('transactions')
        .get();

    double income = 0;
    double expense = 0;

    for (var doc in snapshot.docs) {
      final data = doc.data();
      final amount = double.tryParse(data['amount'].toString()) ?? 0.0;
      final type = data['type'] ?? 'Expense';

      if (type == 'Income') {
        income += amount;
      } else {
        expense += amount;
      }
    }

    setState(() {
      totalIncome = income;
      totalExpense = expense;
    });
  }

  void _navigateAndAddTransaction() async {
    final newTransaction = await Navigator.push<Transactions>(
      context,
      MaterialPageRoute(
        builder: (context) => const AddTransactionScreen(),
      ),
    );

    if (newTransaction != null) {
      fetchTransactionsFromFirebase();
      calculateTotals();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1B1B2F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF00ADB5),
        title: const Text("Dashboard"),
        actions: [
          IconButton(icon: const Icon(Icons.notifications), onPressed: () {})
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateAndAddTransaction,
        backgroundColor: const Color(0xFF00ADB5),
        child: const Icon(Icons.add),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Welcome Back!",
                style: GoogleFonts.poppins(color: Colors.white70, fontSize: 20)),
            Text("Your Expense Overview",
                style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            _buildCard(
                icon: Icons.account_balance_wallet,
                label: 'Total Balance',
                amount: '₹${(totalIncome - totalExpense).toStringAsFixed(2)}'),
            const SizedBox(height: 15),
            Row(
              children: [
                Expanded(
                    child: _buildMiniCard(
                        'Income', '₹${totalIncome.toStringAsFixed(2)}', Icons.arrow_downward, Colors.green)),
                const SizedBox(width: 10),
                Expanded(
                    child: _buildMiniCard('Expenses', '₹${totalExpense.toStringAsFixed(2)}',
                        Icons.arrow_upward, Colors.redAccent)),
              ],
            ),
            const SizedBox(height: 30),
            Text("Recent Transactions",
                style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Expanded(
              child: transactions.isEmpty
                  ? Center(
                  child: Text("No transactions yet",
                      style: GoogleFonts.poppins(color: Colors.white54)))
                  : ListView.builder(
                itemCount: transactions.length,
                itemBuilder: (context, index) {
                  final tx = transactions[index];
                  final icon = tx.type == 'Expense'
                      ? Icons.remove
                      : Icons.add;
                  final color = tx.type == 'Expense'
                      ? Colors.redAccent
                      : Colors.green;

                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: color.withOpacity(0.2),
                      child: Icon(icon, color: color),
                    ),
                    title: Text(tx.title,
                        style: GoogleFonts.poppins(color: Colors.white)),
                    subtitle: Text(
                      '${tx.category} • ${tx.paymentMethod} • ${tx.date.toLocal().toString().split(" ")[0]}',
                      style: GoogleFonts.poppins(
                          color: Colors.white70, fontSize: 12),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit,
                              color: Colors.white70, size: 20),
                          onPressed: () async {
                            final updatedTx =
                            await Navigator.push<Transactions>(
                              context,
                              MaterialPageRoute(
                                builder: (_) => AddTransactionScreen(
                                    transaction: tx),
                              ),
                            );
                            if (updatedTx != null) {
                              fetchTransactionsFromFirebase();
                              calculateTotals();
                            }
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete,
                              color: Colors.redAccent, size: 20),
                          onPressed: () async {
                            final uid =  '101';

                            final query = await FirebaseFirestore.instance
                                .collection('users')
                                .doc(uid)
                                .collection('transactions')
                                .where('title', isEqualTo: tx.title)
                                .where('date',
                                isEqualTo:
                                Timestamp.fromDate(tx.date))
                                .limit(1)
                                .get();
                            if (query.docs.isNotEmpty) {
                              await query.docs.first.reference.delete();
                              fetchTransactionsFromFirebase();
                              calculateTotals();
                            }
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildCard(
      {required IconData icon,
        required String label,
        required String amount}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          color: const Color(0xFF162447),
          borderRadius: BorderRadius.circular(18)),
      child: Row(
        children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label,
                style: GoogleFonts.poppins(color: Colors.white70, fontSize: 14)),
            Text(amount,
                style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20))
          ])
        ],
      ),
    ).animate().fadeIn();
  }

  Widget _buildMiniCard(
      String title, String amount, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: const Color(0xFF162447),
          borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 10),
          Text(title,
              style: GoogleFonts.poppins(color: Colors.white70, fontSize: 14)),
          Text(amount,
              style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
